import React, { useState, useEffect } from 'react';
import { DocumentUpload } from './DocumentUpload';
import { DetailInput } from './DetailInput';
import { SuccessModal } from './SuccessModal';
import { CertificateData } from '../types';

interface CertificateFormProps {
  data: CertificateData;
  type: string;
}

export const CertificateForm: React.FC<CertificateFormProps> = ({ data, type }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRadios, setSelectedRadios] = useState<Record<string, boolean>>({});
  const [canApprove, setCanApprove] = useState(false);

  const handleRadioChange = (label: string, checked: boolean) => {
    setSelectedRadios(prev => ({
      ...prev,
      [label]: checked
    }));
  };

  useEffect(() => {
    const totalItems = [...data.documents, ...data.details].length;
    const selectedCount = Object.values(selectedRadios).filter(Boolean).length;
    setCanApprove(totalItems === selectedCount);
  }, [selectedRadios, data]);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-semibold mb-6">{data.title}</h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium mb-3">Required Documents</h3>
          <div className="space-y-2">
            {data.documents.map((doc) => (
              <DocumentUpload 
                key={doc.label}
                label={doc.label}
                onChange={(checked) => handleRadioChange(doc.label, checked)}
              />
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium mb-3">Details</h3>
          <div className="space-y-2">
            {data.details.map((detail) => (
              <DetailInput
                key={detail.label}
                label={detail.label}
                value={detail.value || ''}
                onChange={(checked) => handleRadioChange(detail.label, checked)}
              />
            ))}
          </div>
        </div>

        <div className="flex justify-end">
          <button
            onClick={() => setIsModalOpen(true)}
            disabled={!canApprove}
            className={`px-4 py-2 rounded transition-colors ${
              canApprove
                ? 'bg-green-600 text-white hover:bg-green-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Approve Application
          </button>
        </div>
      </div>

      <SuccessModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        type={type}
      />
    </div>
  );
};