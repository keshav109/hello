import React from 'react';

interface SuccessModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: string;
}

export const SuccessModal: React.FC<SuccessModalProps> = ({ isOpen, onClose, type }) => {
  if (!isOpen) return null;

  const titles: Record<string, string> = {
    income: 'Income Certificate',
    caste: 'Caste Certificate',
    residence: 'Residence Certificate',
    birth: 'Birth Certificate',
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-6 rounded-lg max-w-md">
        <h3 className="text-xl font-semibold mb-4">Application Approved!</h3>
        <p>The {titles[type]} application has been approved successfully.</p>
        <div className="mt-4 flex justify-end">
          <button
            onClick={onClose}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};