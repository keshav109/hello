import React, { useState } from 'react';
import { FileText, Home, Users, FileCheck } from 'lucide-react';
import { CertificateForm } from './CertificateForm';
import { certificateData } from '../data/certificateData';

const certificates = [
  { id: 'income', label: 'Income Certificate', icon: FileText },
  { id: 'caste', label: 'Caste Certificate', icon: Users },
  { id: 'residence', label: 'Residence Certificate', icon: Home },
  { id: 'birth', label: 'Birth Certificate', icon: FileCheck },
];

export const Dashboard = () => {
  const [selectedCertificate, setSelectedCertificate] = useState('income');

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Certificate Management</h1>
        
        <div className="grid md:grid-cols-4 gap-6">
          {certificates.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setSelectedCertificate(id)}
              className={`p-4 rounded-lg shadow transition-colors ${
                selectedCertificate === id
                  ? 'bg-blue-600 text-white'
                  : 'bg-white hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className="w-5 h-5" />
                <span className="font-medium">{label}</span>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-8">
          <CertificateForm 
            data={certificateData[selectedCertificate]}
            type={selectedCertificate}
          />
        </div>
      </div>
    </div>
  );
};