import React from 'react';
import { FileText } from 'lucide-react';

interface DocumentUploadProps {
  label: string;
  onChange: (checked: boolean) => void;
}

export const DocumentUpload: React.FC<DocumentUploadProps> = ({ label, onChange }) => (
  <div className="flex items-center gap-2 mb-2">
    <input 
      type="radio" 
      name={`approval-${label}`}
      className="w-4 h-4"
      onChange={(e) => onChange(e.target.checked)}
    />
    <span className="flex items-center gap-2">
      <FileText className="w-4 h-4" />
      {label}
    </span>
  </div>
);