import React from 'react';

interface IncomeInputProps {
  label: string;
  value: string;
}

export const IncomeInput: React.FC<IncomeInputProps> = ({ label, value }) => (
  <div className="flex items-center gap-2 mb-2">
    <input 
      type="radio" 
      name={`approval-${label}`}
      className="w-4 h-4" 
    />
    <label className="flex-1">{label}</label>
    <input
      type="text"
      value={value}
      readOnly
      className="border rounded px-2 py-1 w-32"
    />
  </div>
);