import React from 'react';

interface DetailInputProps {
  label: string;
  value: string;
  onChange: (checked: boolean) => void;
}

export const DetailInput: React.FC<DetailInputProps> = ({ label, value, onChange }) => (
  <div className="flex items-center gap-2 mb-2">
    <input 
      type="radio" 
      name={`approval-${label}`}
      className="w-4 h-4"
      onChange={(e) => onChange(e.target.checked)}
    />
    <label className="flex-1">{label}</label>
    <input
      type="text"
      value={value}
      readOnly
      className="border rounded px-2 py-1 w-32"
    />
  </div>
);