import { CertificateData } from '../types';

export const certificateData: Record<string, CertificateData> = {
  income: {
    title: 'Income Certificate',
    documents: [
      { label: 'Aadhaar Card (ID: 1234 5678 9012)' },
      { label: 'Latest IT Returns' },
      { label: 'Payment Slips' },
    ],
    details: [
      { label: 'Income from Land', value: '₹25,000' },
      { label: 'Income from Business', value: '₹1,50,000' },
      { label: 'Wife\'s Income', value: '₹75,000' },
      { label: 'Husband\'s Income', value: '₹2,00,000' },
      { label: 'Income from Labour', value: '₹30,000' },
      { label: 'Other Income', value: '₹15,000' },
    ],
  },
  caste: {
    title: 'Caste Certificate',
    documents: [
      { label: 'Aadhaar Card (ID: 1234 5678 9012)' },
      { label: 'Parent\'s Caste Certificate' },
      { label: 'Community Certificate' },
    ],
    details: [
      { label: 'Community Name', value: 'Sample Community' },
      { label: 'Sub-caste', value: 'Sample Sub-caste' },
      { label: 'Religion', value: 'Sample Religion' },
    ],
  },
  residence: {
    title: 'Residence Certificate',
    documents: [
      { label: 'Aadhaar Card (ID: 1234 5678 9012)' },
      { label: 'Electricity Bill' },
      { label: 'Rental Agreement' },
    ],
    details: [
      { label: 'Current Address', value: '123 Main St' },
      { label: 'Duration of Stay', value: '5 years' },
      { label: 'Property Type', value: 'Residential' },
    ],
  },
  birth: {
    title: 'Birth Certificate',
    documents: [
      { label: 'Hospital Record' },
      { label: 'Parent\'s ID Proof' },
      { label: 'Address Proof' },
    ],
    details: [
      { label: 'Date of Birth', value: '01/01/2000' },
      { label: 'Place of Birth', value: 'City Hospital' },
      { label: 'Parent Names', value: 'John & Jane Doe' },
    ],
  },
};