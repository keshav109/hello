export interface DocumentInfo {
  label: string;
  value?: string;
}

export interface CertificateData {
  title: string;
  documents: DocumentInfo[];
  details: DocumentInfo[];
}